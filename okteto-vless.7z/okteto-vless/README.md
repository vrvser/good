
okteto 注册地址： https://cloud.okteto.com

详情见： https://github.com/yunbaitech666/okvtwo
